package com.example.pmictool

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager

/**
 * CH341A in I2C mode, talking over the vendor's USB bulk "I2C stream" protocol.
 *
 * This lets you probe/read/write PMIC chips over I2C (SDA/SCL) instead of the
 * SPI mode used for 25xx flash chips. Physically this uses the same CH341A
 * board, but the SDA/SCL pins (not the SPI pins) must be wired to the PMIC's
 * I2C bus, plus GND and the panel's own logic-level supply as reference
 * (do NOT power the PMIC from the CH341A — it should already be powered by
 * the TV board, or a bench supply at the correct voltage).
 *
 * Protocol constants match the widely-used open CH341A vendor command set.
 */
class Ch341I2c(private val usbManager: UsbManager, private val device: UsbDevice) {

    companion object {
        const val VENDOR_ID = 0x1A86
        const val PRODUCT_ID = 0x5512

        private const val CMD_I2C_STREAM = 0xAA
        private const val CMD_I2C_STM_START = 0x74
        private const val CMD_I2C_STM_STOP = 0x75
        private const val CMD_I2C_STM_OUT = 0x80   // | length (0-63) of bytes to write
        private const val CMD_I2C_STM_IN = 0xC0    // | length (0-63) of bytes to read
        private const val CMD_I2C_STM_SET = 0x60   // | speed bits (0=20kHz,1=100kHz,2=400kHz,3=750kHz)
        private const val CMD_I2C_STM_END = 0x00

        private const val SPEED_100K = 0x01
    }

    private var connection: UsbDeviceConnection? = null
    private var bulkOut: UsbEndpoint? = null
    private var bulkIn: UsbEndpoint? = null

    fun hasPermission(): Boolean = usbManager.hasPermission(device)

    fun open(): Boolean {
        val conn = usbManager.openDevice(device) ?: return false
        val iface: UsbInterface = device.getInterface(0)
        conn.claimInterface(iface, true)
        for (i in 0 until iface.endpointCount) {
            val ep = iface.getEndpoint(i)
            if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                if (ep.direction == UsbConstants.USB_DIR_OUT) bulkOut = ep
                if (ep.direction == UsbConstants.USB_DIR_IN) bulkIn = ep
            }
        }
        connection = conn
        setSpeed(SPEED_100K)
        return bulkOut != null && bulkIn != null
    }

    fun close() {
        connection?.close()
        connection = null
    }

    private fun setSpeed(speedBits: Int) {
        val packet = byteArrayOf((CMD_I2C_STREAM).toByte(), (CMD_I2C_STM_SET or speedBits).toByte(), CMD_I2C_STM_END.toByte())
        bulkWrite(packet)
    }

    private fun bulkWrite(data: ByteArray): Int {
        val ep = bulkOut ?: return -1
        return connection?.bulkTransfer(ep, data, data.size, 1000) ?: -1
    }

    private fun bulkRead(length: Int): ByteArray {
        val ep = bulkIn ?: return ByteArray(0)
        val buf = ByteArray(length)
        val n = connection?.bulkTransfer(ep, buf, length, 1000) ?: -1
        return if (n > 0) buf.copyOf(n) else ByteArray(0)
    }

    /**
     * Probe the bus for a device ACKing at the given 7-bit address.
     * Returns true if a chip responds (used for auto-detecting a PMIC's address).
     */
    fun probe(address7bit: Int): Boolean {
        val writeAddr = (address7bit shl 1) or 0 // write bit = 0
        val packet = mutableListOf<Byte>()
        packet.add(CMD_I2C_STREAM.toByte())
        packet.add(CMD_I2C_STM_START.toByte())
        packet.add((CMD_I2C_STM_OUT or 1).toByte())
        packet.add(writeAddr.toByte())
        packet.add(CMD_I2C_STM_STOP.toByte())
        packet.add(CMD_I2C_STM_END.toByte())
        bulkWrite(packet.toByteArray())
        val resp = bulkRead(1)
        // CH341A returns an ACK/NACK status byte per OUT stage; bit layout can
        // vary slightly by firmware revision — treat "got a non-empty response
        // without a bus error" as a detected device for common PMIC addresses.
        return resp.isNotEmpty()
    }

    /** Scan the standard 7-bit I2C address range for any responding device. */
    fun scanBus(): List<Int> {
        val found = mutableListOf<Int>()
        for (addr in 0x08..0x77) {
            if (probe(addr)) found.add(addr)
        }
        return found
    }

    /** Read `length` bytes starting at an 8-bit register address from a PMIC at address7bit. */
    fun readRegister(address7bit: Int, register: Int, length: Int): ByteArray {
        val writeAddr = (address7bit shl 1) or 0
        val readAddr = (address7bit shl 1) or 1
        val packet = mutableListOf<Byte>()
        packet.add(CMD_I2C_STREAM.toByte())
        packet.add(CMD_I2C_STM_START.toByte())
        packet.add((CMD_I2C_STM_OUT or 2).toByte())
        packet.add(writeAddr.toByte())
        packet.add(register.toByte())
        packet.add(CMD_I2C_STM_START.toByte()) // repeated start
        packet.add((CMD_I2C_STM_OUT or 1).toByte())
        packet.add(readAddr.toByte())
        packet.add((CMD_I2C_STM_IN or length).toByte())
        packet.add(CMD_I2C_STM_STOP.toByte())
        packet.add(CMD_I2C_STM_END.toByte())
        bulkWrite(packet.toByteArray())
        return bulkRead(length)
    }

    /** Write `data` starting at an 8-bit register address on a PMIC at address7bit. */
    fun writeRegister(address7bit: Int, register: Int, data: ByteArray): Boolean {
        val writeAddr = (address7bit shl 1) or 0
        val packet = mutableListOf<Byte>()
        packet.add(CMD_I2C_STREAM.toByte())
        packet.add(CMD_I2C_STM_START.toByte())
        packet.add((CMD_I2C_STM_OUT or (data.size + 2)).toByte())
        packet.add(writeAddr.toByte())
        packet.add(register.toByte())
        data.forEach { packet.add(it) }
        packet.add(CMD_I2C_STM_STOP.toByte())
        packet.add(CMD_I2C_STM_END.toByte())
        return bulkWrite(packet.toByteArray()) > 0
    }
}
