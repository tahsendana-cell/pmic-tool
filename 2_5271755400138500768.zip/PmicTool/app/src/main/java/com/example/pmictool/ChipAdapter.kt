package com.example.pmictool

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChipAdapter(private var groups: List<ChipGroup>) :
    RecyclerView.Adapter<ChipAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.chipGroupTitle)
        val chips: TextView = view.findViewById(R.id.chipGroupList)
    }

    fun updateData(newGroups: List<ChipGroup>) {
        groups = newGroups
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chip_group, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val group = groups[position]
        holder.title.text = "Group #${group.id} — ${group.protocol}"
        holder.chips.text = group.chips.joinToString(", ")
    }

    override fun getItemCount() = groups.size
}
