package com.example.pmictool

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var searchBox: EditText
    private lateinit var statusText: TextView
    private lateinit var resultsList: RecyclerView
    private lateinit var adapter: ChipAdapter

    private lateinit var usbManager: UsbManager
    private var i2c: Ch341I2c? = null

    private val ACTION_USB_PERMISSION = "com.example.pmictool.USB_PERMISSION"

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ACTION_USB_PERMISSION) {
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                val device: UsbDevice? = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                if (granted && device != null) {
                    connectToDevice(device)
                } else {
                    statusText.text = "Status: USB permission denied"
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ChipDatabase.load(this)

        searchBox = findViewById(R.id.searchBox)
        statusText = findViewById(R.id.statusText)
        resultsList = findViewById(R.id.resultsList)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        adapter = ChipAdapter(ChipDatabase.allGroups())
        resultsList.layoutManager = LinearLayoutManager(this)
        resultsList.adapter = adapter

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString().orEmpty()
                adapter.updateData(ChipDatabase.findPartial(query))
            }
        })

        findViewById<Button>(R.id.btnConnect).setOnClickListener { requestConnection() }
        findViewById<Button>(R.id.btnScanBus).setOnClickListener { scanBus() }

        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbReceiver, filter)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        i2c?.close()
        unregisterReceiver(usbReceiver)
    }

    private fun findCh341Device(): UsbDevice? =
        usbManager.deviceList.values.firstOrNull {
            it.vendorId == Ch341I2c.VENDOR_ID && it.productId == Ch341I2c.PRODUCT_ID
        }

    private fun requestConnection() {
        val device = findCh341Device()
        if (device == null) {
            statusText.text = "Status: no CH341A found (check OTG cable + connection)"
            return
        }
        if (usbManager.hasPermission(device)) {
            connectToDevice(device)
        } else {
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(this, 0, Intent(ACTION_USB_PERMISSION), flags)
            usbManager.requestPermission(device, pi)
        }
    }

    private fun connectToDevice(device: UsbDevice) {
        val bridge = Ch341I2c(usbManager, device)
        if (bridge.open()) {
            i2c = bridge
            statusText.text = "Status: connected to CH341A (I2C mode, 100kHz)"
        } else {
            statusText.text = "Status: failed to open CH341A"
        }
    }

    private fun scanBus() {
        val bridge = i2c
        if (bridge == null) {
            Toast.makeText(this, "Connect to CH341A first", Toast.LENGTH_SHORT).show()
            return
        }
        statusText.text = "Status: scanning I2C bus..."
        Thread {
            val found = bridge.scanBus()
            runOnUiThread {
                statusText.text = if (found.isEmpty())
                    "Status: no I2C devices responded"
                else
                    "Status: found device(s) at " + found.joinToString(", ") { "0x%02X".format(it) }
            }
        }.start()
    }
}
