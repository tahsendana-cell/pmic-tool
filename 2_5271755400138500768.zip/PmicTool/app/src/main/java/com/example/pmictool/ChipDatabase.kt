package com.example.pmictool

import android.content.Context
import org.json.JSONObject

data class ChipGroup(val id: Int, val protocol: String, val chips: List<String>)

object ChipDatabase {

    private var groups: List<ChipGroup> = emptyList()

    /** Load tcon_vgh_vgl_chips.json from app assets. Call once, e.g. in onCreate. */
    fun load(context: Context) {
        val text = context.assets.open("tcon_vgh_vgl_chips.json")
            .bufferedReader(Charsets.UTF_8).use { it.readText() }
        val root = JSONObject(text)
        val arr = root.getJSONArray("groups")
        val list = mutableListOf<ChipGroup>()
        for (i in 0 until arr.length()) {
            val g = arr.getJSONObject(i)
            val chipsArr = g.getJSONArray("chips")
            val chips = (0 until chipsArr.length()).map { chipsArr.getString(it) }
            list.add(ChipGroup(g.getInt("id"), g.optString("protocol", "unknown"), chips))
        }
        groups = list
    }

    fun allGroups(): List<ChipGroup> = groups

    private fun normalize(s: String) = s.trim().uppercase().replace(" ", "").replace("/", "-")

    /** Exact match: chip name -> its full interchange group, or null if not found. */
    fun findExact(query: String): ChipGroup? {
        val q = normalize(query)
        return groups.firstOrNull { group -> group.chips.any { normalize(it) == q } }
    }

    /** Partial/substring match across all chip names, for live search-as-you-type. */
    fun findPartial(query: String): List<ChipGroup> {
        if (query.isBlank()) return groups
        val q = normalize(query)
        return groups.filter { group -> group.chips.any { normalize(it).contains(q) } }
    }
}
